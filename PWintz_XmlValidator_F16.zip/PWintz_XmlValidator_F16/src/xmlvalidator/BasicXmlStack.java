package xmlvalidator;

public class BasicXmlStack extends BasicStringStack {

}
